Import or export browsing history 

[![](https://raw.githubusercontent.com/igorlogius/igorlogius/main/geFxAddon.png)](https://addons.mozilla.org/firefox/addon/history-porter/)

### [Click here to report a bug, make a suggestion or ask a question](https://github.com/igorlogius/igorlogius/issues/new/choose)

<b>Short Demo Video:</b>

tbd.

<b>Quick Start Instructions:</b>
<ol>
  <li>tbd.</li>
</ol>

